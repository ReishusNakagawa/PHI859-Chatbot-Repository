from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

# Replace these with your Poe API details
POE_API_URL = "https://poe.com/TransformerBotPHI859"  # Replace with the actual endpoint
POE_API_KEY = "v3W_Ec_Dh4EDVhqWBkwZjpVl70Flfo5FHaz8jTZynwk"  # Replace with your actual API key

@app.route('/chat', methods=['POST'])
def chat():
    try:
        # Get the user's message from the frontend
        user_message = request.json.get("message")

        # Prepare the request to the Poe API
        headers = {
            "Authorization": f"Bearer {POE_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {"message": user_message}

        # Send the request to the Poe API
        response = requests.post(POE_API_URL, json=payload, headers=headers)
        response.raise_for_status()  # Raise an error if the request fails

        # Extract and return the bot's response
        bot_response = response.json().get("response", "No response received.")
        return jsonify({"response": bot_response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(port=5000)
